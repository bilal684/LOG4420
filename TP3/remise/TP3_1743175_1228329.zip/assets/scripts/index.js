$(function(){
    //On update le shopping cart badge lorsque sur index.html.
    utilities.updateShoppingCartBadge()
})