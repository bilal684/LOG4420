$(function(){
    //On update le shopping cart badge lorsque sur contact.html
    utilities.updateShoppingCartBadge()
})